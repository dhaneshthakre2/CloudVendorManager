package com.demoapi.JavaSpringbootRestapiCrud2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringbootRestapiCrud2Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringbootRestapiCrud2Application.class, args);
	}

}
