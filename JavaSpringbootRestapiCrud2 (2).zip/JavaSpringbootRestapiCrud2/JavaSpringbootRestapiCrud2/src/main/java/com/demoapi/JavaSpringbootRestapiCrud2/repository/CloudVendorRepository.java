package com.demoapi.JavaSpringbootRestapiCrud2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demoapi.JavaSpringbootRestapiCrud2.model.CloudVendor;

public interface CloudVendorRepository extends JpaRepository<CloudVendor, String> {

//	jpaRepository will gives you a lot of methods so u need not to actually declare a define actual methods
//	such as if you want save any thing in your database u have not actually suppose to define a save method
//because this JpaRepository will already provides this all if you want to define any custom method.
}
